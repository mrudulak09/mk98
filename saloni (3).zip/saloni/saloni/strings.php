<?php
echo "<!DOCTYPE html>
<html>
<head>
<title>PHP String Operations</title>
<style>
body {
font-family: Arial, sans-serif;
background-color: #e8f0fe;
color: #333;
margin: 0;
padding: 20px;
}
.container {
background-color: #ffffff;
border-radius: 10px;
box-shadow: 0 0 10px rgba(0,0,0,0.1);
padding: 20px;
max-width: 800px;
margin: auto;
}
h3 {
color: #007BFF;
border-bottom: 2px solid #007BFF;
padding-bottom: 5px;
}
.output {
background-color: #f9f9f9;
padding: 10px;
border: 1px solid #ddd;
border-radius: 5px;
margin-bottom: 20px;
}
</style>
</head>
<body>
<div class='container'>
<h1>PHP String Operations</h1>";
// String declaration
$string1 = "Hello";
$string2 = "World!";
$longString = "
PHP string operations are fun to learn!
";
$text = "The quick brown fox jumps over the lazy dog";
// 1. String Concatenation
echo "<h3>1. String Concatenation</h3>";
$concatenatedString = $string1 . " " . $string2;
echo "<div class='output'>Concatenated String: " . $concatenatedString .
"</div>";
// 2. String Length
echo "<h3>2. String Length</h3>";
$length = strlen($concatenatedString);
echo "<div class='output'>Length of Concatenated String: " . $length .
"</div>";
// 3. String Upper and Lowercase Conversion
echo "<h3>3. Upper and Lowercase Conversion</h3>";
$upperCase = strtoupper($concatenatedString);
$lowerCase = strtolower($concatenatedString);
echo "<div class='output'>Uppercase: " . $upperCase . "<br>Lowercase: " .
$lowerCase . "</div>";
// 4. Substring
echo "<h3>4. Substring</h3>";
$substring = substr($concatenatedString, 0, 5);
echo "<div class='output'>First 5 characters of concatenated string: " .
$substring . "</div>";
// 5. String Replace
echo "<h3>5. String Replace</h3>";
$replacedString = str_replace("World", "PHP", $concatenatedString);
echo "<div class='output'>String after Replacement: " . $replacedString .
"</div>";
// 6. Trimming Whitespaces
echo "<h3>6. Trimming Whitespaces</h3>";
$trimmedString = trim($longString);
echo "<div class='output'>String after Trim: '" . $trimmedString .
"'</div>";
// 7. Find Position of a Substring
echo "<h3>7. Finding Position of a Substring</h3>";
$position = strpos($text, "fox");
if ($position !== false) {
echo "<div class='output'>Position of 'fox' in text: " . $position .
"</div>";
} else {
echo "<div class='output'>Substring 'fox' not found.</div>";
}
// 8. String Repeat
echo "<h3>8. String Repeat</h3>";
$repeatedString = str_repeat($string1, 3);
echo "<div class='output'>Repeated String: " . $repeatedString . "</div>";
// 9. String Reverse
echo "<h3>9. String Reverse</h3>";
$reversedString = strrev($concatenatedString);
echo "<div class='output'>Reversed String: " . $reversedString . "</div>";
// 10. Explode (Convert String to Array)
echo "<h3>10. Explode (String to Array)</h3>";
$wordArray = explode(" ", $text);
echo "<div class='output'>Exploded String (Array): <pre>" .
print_r($wordArray, true) . "</pre></div>";
// 11. Implode (Convert Array to String)
echo "<h3>11. Implode (Array to String)</h3>";
$implodedString = implode(", ", $wordArray);
echo "<div class='output'>Imploded String: " . $implodedString . "</div>";
echo "</div>
</body>
</html>";
?>
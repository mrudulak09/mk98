<?php
if (isset($_COOKIE["username"])) {
$username = htmlspecialchars($_COOKIE["username"]);
} else {
header("Location: set_cookie.php");
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Welcome Page</title>
<style>
    body {
background-color: #e6ffe6;
font-family: Arial, sans-serif;
}
.container {
text-align: center;
margin-top: 100px;
}
.container a {
display: inline-block;
padding: 10px;
margin-top: 20px;
background-color: #4CAF50;
color: white;
text-decoration: none;
}
.container a:hover {
background-color: #45a049;
}
</style>
</head>
<body>
<div class="container">
<h2>Welcome back, <?php echo $username; ?>!</h2>
<p>We remembered you because of your cookie!</p>
<a href="delete_cookie.php">Logout and Delete Cookie</a>
</div>
</body>
</html>
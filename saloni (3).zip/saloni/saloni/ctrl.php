<?php
echo "<!DOCTYPE html>
<html>
<head>
<title>PHP Control Statements</title>
<style>
body {
font-family: Arial, sans-serif;
background-color: #f4f4f9;
color: #333;
margin: 0;
padding: 20px;
}
.container {
background-color: #ffffff;
border-radius: 10px;
box-shadow: 0 0 10px rgba(0,0,0,0.1);
padding: 20px;
max-width: 800px;
margin: auto;
}
h3 {
color: #4CAF50;
border-bottom: 2px solid #4CAF50;
padding-bottom: 5px;
}
.output {
background-color: #f9f9f9;
padding: 10px;
border: 1px solid #ddd;
border-radius: 5px;
margin-bottom: 20px;
}
</style>
</head>
<body>
<div class='container'>
<h1>PHP Control Statements</h1>";
// 1. IF-ELSE Statement
$number = 10;
echo "<h3>1. IF-ELSE Statement</h3>";
echo "<div class='output'>";
if ($number > 0) {
echo "$number is positive.<br>";
} elseif ($number == 0) {
echo "$number is zero.<br>";
} else {
echo "$number is negative.<br>";
}
echo "</div>";
// 2. SWITCH Statement
$day = 2;
echo "<h3>2. SWITCH Statement</h3>";
echo "<div class='output'>";
switch ($day) {
case 1:
echo "Today is Monday.<br>";
break;
case 2:
echo "Today is Tuesday.<br>";
break;
case 3:
    echo "Today is Wednesday.<br>";
    break;
    case 4:
    echo "Today is Thursday.<br>";
    break;
    case 5:
    echo "Today is Friday.<br>";
    break;
    case 6:
    echo "Today is Saturday.<br>";
    break;
    case 7:
    echo "Today is Sunday.<br>";
    break;
    default:
    echo "Invalid day number.<br>";
    break;
    }
    echo "</div>";
// 3. FOR Loop
echo "<h3>3. FOR Loop</h3>";
echo "<div class='output'>";
echo "Numbers from 1 to 5:<br>";
for ($i = 1; $i <= 5; $i++) {
echo $i . "<br>";
}
echo "</div>";
// 4. WHILE Loop
echo "<h3>4. WHILE Loop</h3>";
echo "<div class='output'>";
$counter = 1;
echo "Numbers from 1 to 5 using while loop:<br>";
while ($counter <= 5) {
echo $counter . "<br>";
$counter++;
}
echo "</div>";
// 5. DO-WHILE Loop
echo "<h3>5. DO-WHILE Loop</h3>";
echo "<div class='output'>";
$counter = 1;
echo "Numbers from 1 to 5 using do-while loop:<br>";
do {
    echo $counter . "<br>";
$counter++;
} while ($counter <= 5);
echo "</div>";
// 6. FOREACH Loop
echo "<h3>6. FOREACH Loop</h3>";
echo "<div class='output'>";
$fruits = array("Apple", "Banana", "Cherry", "Mango");
echo "List of fruits:<br>";
foreach ($fruits as $fruit) {
echo $fruit . "<br>";
}
echo "</div>";
// 7. BREAK Statement
echo "<h3>7. BREAK Statement</h3>";
echo "<div class='output'>";
echo "Break the loop at number 3:<br>";
for ($i = 1; $i <= 5; $i++) {
if ($i == 3) {
echo "Breaking the loop at number $i.<br>";
break;
}
echo $i . "<br>";
}
echo "</div>";
// 8. CONTINUE Statement
echo "<h3>8. CONTINUE Statement</h3>";
echo "<div class='output'>";
echo "Skipping number 3 using continue:<br>";
for ($i = 1; $i <= 5; $i++) {
if ($i == 3) {
continue;
}
echo $i . "<br>";
}
echo "</div>";
echo "</div>
</body>
</html>";
?>
<?php
// Delete the username cookie by setting its expiration time in the past
setcookie("username", "", time() - 3600, "/");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Logout</title>
    <style>
        body {
            background-color: #ffe6e6;
            font-family: Arial, sans-serif;
        }
        .container {
            text-align: center;
            margin-top: 100px;
        }
        .container p {
            font-size: 18px;
            color: #333;
        }
        .container a {
            display: inline-block;
            padding: 10px;
            margin-top: 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .container a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>You have been logged out!</h2>
        <p>Your cookie has been successfully deleted.</p>
        <a href="set_cookie.php">Go to Set Cookie Page</a>
    </div>
</body>
</html>


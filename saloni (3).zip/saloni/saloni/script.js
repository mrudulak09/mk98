document.getElementById('clickButton').addEventListener('click',
function() {
document.getElementById('result').textContent = 'Button clicked! You activated an event.';
document.getElementById('result').style.color = '#4CAF50';
});
document.getElementById('inputField').addEventListener('input', function()
{
if (this.value) {
document.getElementById('result').textContent = 'You entered: ' +
this.value;
document.getElementById('result').style.color = '#333';
} else {
document.getElementById('result').textContent = '';
}
});
document.getElementById('hoverArea').addEventListener('mouseover',
function() {
this.style.backgroundColor = '#3CB371';
document.getElementById('result').textContent = 'Hovering detected!';
document.getElementById('result').style.color = '#3CB371';
});
document.getElementById('hoverArea').addEventListener('mouseout',
function() {
this.style.backgroundColor = '#87CEEB';
});
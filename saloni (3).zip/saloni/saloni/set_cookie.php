<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$username = htmlspecialchars($_POST['username']);
setcookie("username", $username, time() + 20, "/");
header("Location: welcome_cookie.php");
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Set Cookie</title>
<style>
body {
background-color: #f0f8ff;
font-family: Arial, sans-serif;
}
form {
margin-top: 100px;
text-align: center;
}
input[type="text"], input[type="submit"] {
padding: 10px;
margin: 5px;
}
input[type="submit"] {
background-color: #4CAF50;
color: white;
border: none;
cursor: pointer;
}
</style>
</head>
<body>
<h2 style="text-align:center;">Set a Cookie</h2>
<form method="POST" action="set_cookie.php">
<label for="username">Enter your name:</label>
<input type="text" id="username" name="username" required>
<br><br>
<input type="submit" value="Set Cookie">
</form>
</body>
</html>
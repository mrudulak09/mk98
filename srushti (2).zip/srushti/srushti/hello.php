<?php
// Example PHP script
echo "Hello, World!";
?>

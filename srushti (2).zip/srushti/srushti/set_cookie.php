<?php
// Set a cookie that expires in 1 hour
$cookie_name = "user";
$cookie_value = "John Doe";
setcookie($cookie_name, $cookie_value, time() + (3600), "/"); // 3600 seconds = 1 hour

// Check if the cookie is set
if (isset($_COOKIE[$cookie_name])) {
    echo "Cookie '$cookie_name' is already set!<br>";
} else {
    echo "Cookie '$cookie_name' has been set!<br>";
}

// Provide a link to get the cookie
echo "<a href='get_cookie.php'>Go to Get Cookie</a><br>";
echo "<a href='delete_cookie.php'>Go to Delete Cookie</a>";
?>

<?php
// If-else statement
$age = 20;
echo "If-Else Statement:<br>";
if ($age < 18) {
    echo "You are a minor.<br>";
} elseif ($age >= 18 && $age < 60) {
    echo "You are an adult.<br>";
} else {
    echo "You are a senior citizen.<br>";
}

// Line break
echo "<br>";

// Switch statement
$day = "Monday";
echo "Switch Statement:<br>";
switch ($day) {
    case "Monday":
        echo "Start of the work week.<br>";
        break;
    case "Wednesday":
        echo "Midweek.<br>";
        break;
    case "Friday":
        echo "Almost weekend!<br>";
        break;
    default:
        echo "It's just another day.<br>";
}

// Line break
echo "<br>";

// For loop
echo "For Loop Example:<br>";
for ($i = 1; $i <= 5; $i++) {
    echo "Number: $i<br>";
}

// Line break
echo "<br>";

// While loop
echo "While Loop Example:<br>";
$count = 1;
while ($count <= 5) {
    echo "Count is: $count<br>";
    $count++;
}

// Line break
echo "<br>";

// Do-while loop
echo "Do-While Loop Example:<br>";
$count = 1;
do {
    echo "Count is: $count<br>";
    $count++;
} while ($count <= 5);
?>

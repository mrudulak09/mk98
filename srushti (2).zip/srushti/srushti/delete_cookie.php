<?php
// Set the cookie expiration time to a past time to delete it
setcookie("user", "", time() - 3600, "/");

echo "Cookie 'user' has been deleted.<br>";

// Provide links to set or get the cookie
echo "<a href='set_cookie.php'>Set Cookie</a><br>";
echo "<a href='get_cookie.php'>Get Cookie</a>";
?>


<?php
// Check if the cookie is set
if (isset($_COOKIE['user'])) {
    echo "Hello, " . $_COOKIE['user'] . "!<br>";
} else {
    echo "Cookie 'user' is not set.<br>";
}

// Provide a link to set the cookie again
echo "<a href='set_cookie.php'>Set Cookie Again</a><br>";
echo "<a href='delete_cookie.php'>Go to Delete Cookie</a>";
?>

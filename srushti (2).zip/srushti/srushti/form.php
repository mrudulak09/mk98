<?php
// Initialize variables to hold the form data and messages
$name = $email = $phone = $gender = $interests = $message = "";
$error = "";
$success = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input data
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $phone = htmlspecialchars(trim($_POST['phone']));
    $gender = htmlspecialchars(trim($_POST['gender']));
    $interests = isset($_POST['interests']) ? $_POST['interests'] : [];
    $message = htmlspecialchars(trim($_POST['message']));

    // Validate input
    if (empty($name) || empty($email) || empty($phone) || empty($gender)) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Success message
        $success = "Thank you, $name!<br>Your email is $email.<br>Your phone number is $phone.<br>Your gender is $gender.<br>Interests: " . implode(", ", $interests) . ".<br>Message: $message";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Form Handling</title>
</head>
<body>
    <h2>PHP Form Creation and Data Handling</h2>
    
    <!-- Display error or success message -->
    <?php if (!empty($error)): ?>
        <div style="color: red;"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <?php if (!empty($success)): ?>
        <div style="color: green;"><?php echo $success; ?></div>
    <?php endif; ?>

    <!-- Form -->
    <form method="post" action="">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="phone">Phone Number:</label><br>
        <input type="tel" id="phone" name="phone" required><br><br>

        <label for="gender">Gender:</label><br>
        <input type="radio" id="male" name="gender" value="Male" required>
        <label for="male">Male</label><br>
        <input type="radio" id="female" name="gender" value="Female">
        <label for="female">Female</label><br>
        <input type="radio" id="other" name="gender" value="Other">
        <label for="other">Other</label><br><br>

        <label for="interests">Interests:</label><br>
        <input type="checkbox" id="coding" name="interests[]" value="Coding">
        <label for="coding">Coding</label><br>
        <input type="checkbox" id="music" name="interests[]" value="Music">
        <label for="music">Music</label><br>
        <input type="checkbox" id="sports" name="interests[]" value="Sports">
        <label for="sports">Sports</label><br><br>

        <label for="message">Message:</label><br>
        <textarea id="message" name="message" rows="4" cols="50"></textarea><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>

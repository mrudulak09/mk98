<?php
// Define a string
$originalString = "Hello, World!";
echo "Original String is : Hello, World!<br>";

// 1. String Length
$length = strlen($originalString);
echo "1. String Length: $length<br>";

// 2. String Concatenation
$additionalString = " Welcome to PHP!";
$concatenatedString = $originalString . $additionalString;
echo "2. Concatenated String: $concatenatedString<br>";

// 3. String Case Conversion
$upperCaseString = strtoupper($originalString);
$lowerCaseString = strtolower($originalString);
echo "3. Uppercase: $upperCaseString<br>";
echo "   Lowercase: $lowerCaseString<br>";

// 4. Substring
$substring = substr($originalString, 7, 5); // Get 5 characters starting from index 7
echo "4. Substring (from index 7): $substring<br>";

// 5. String Search
$searchString = "World";
$position = strpos($originalString, $searchString);
if ($position !== false) {
    echo "5. '$searchString' found at position: $position<br>";
} else {
    echo "5. '$searchString' not found.<br>";
}

// 6. String Replace
$replacedString = str_replace("World", "PHP", $originalString);
echo "6. Replaced String: $replacedString<br>";

// 7. String Split
$stringToSplit = "apple,banana,cherry";
$splittedArray = explode(",", $stringToSplit);
echo "7. Splitted String:<br>";
foreach ($splittedArray as $fruit) {
    echo "- $fruit<br>";
}

// 8. Trim String
$trimmedString = "   Hello, PHP!   ";
echo "8. Trimmed String: '" . trim($trimmedString) . "'<br>";

?>

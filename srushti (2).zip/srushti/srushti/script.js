// Select the button and paragraph elements
const button = document.getElementById('myButton');
const resetButton = document.getElementById('resetButton');
const paragraph = document.getElementById('myParagraph');

// Define the event handler function to change text
function changeText() {
    paragraph.textContent = 'The text has been changed!';
}

// Define the event handler function to reset text
function resetText() {
    paragraph.textContent = 'This text will change when you click the button.';
}

// Attach the event handler to the button's click event
button.addEventListener('click', changeText);

// Attach the event handler to the reset button's click event
resetButton.addEventListener('click', resetText);

